<template>
  <v-app>
    <v-container >
        <router-view></router-view>  
    </v-container>
  </v-app>
</template>

<script>


export default {
  name: "App",

  data: () => ({
    //
  })
};
</script>
<style>
  #loginTab {
    float: right;
  }
</style>
