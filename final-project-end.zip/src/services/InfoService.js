// import axios from 'axios'

// const apiClient = axios.create({
//   baseURL: `http://localhost:8080`,
//   withCredentials: false, // This is the default
//   headers: {
//     Accept: 'application/json',
//     'Content-Type': 'application/json'
//   }
// })

// export default {
//   getInfos(id) {
//     return apiClient.get('/infos/' + id)
//   },
//   postInfo(info) {
//     return apiClient.post('/infos', info)
//   }
// }
